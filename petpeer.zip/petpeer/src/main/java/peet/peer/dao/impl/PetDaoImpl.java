package peet.peer.dao.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import peet.peer.dao.*;
import peet.peer.repository.PetRepository;

import peet.peer.entity.*;


@Service
public class PetDaoImpl implements PetDao {
	
	@Autowired
	private PetRepository petRepository;
	
	
	@Override
	public Pet savePet(Pet pet) {
		return petRepository.save(pet);
	}
	
	@Override
	public java.util.List<Pet> fetchPet(Pet fetchpet){
		return petRepository.findAll();
	}

}
