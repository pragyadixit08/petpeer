package peet.peer.entity;

import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name ="pets")
public class Pet {
	
	
	
		
		@Id
		@GeneratedValue(strategy = GenerationType.AUTO)
		private Long id;
		@Column(name="PET_Name")
		private String petName;
		@Column(name="PET_AGE")
		private Integer petAge;
		@Column(name="PET_PLACE")
		private String petPlace;
		@Column(name="PET_OWNERID")
		@OneToMany(mappedBy="id")
		private Set<User> petOwnerId;
		public String getPetName() {
			return petName;
		}
		public void setPetName(String petName) {
			this.petName = petName;
		}
		public Integer getPetAge() {
			return petAge;
		}
		public void setPetAge(Integer petAge) {
			this.petAge = petAge;
		}
		public String getPetPlace() {
			return petPlace;
		}
		public void setPetPlace(String petPlace) {
			this.petPlace = petPlace;
		}
		public Set<User> getPetOwnerId() {
			return petOwnerId;
		}
		public void setPetOwnerId(Set<User> petOwnerId) {
			this.petOwnerId = petOwnerId;
		}
		public void setId(Long id) {
			this.id = id;
		}
		
		public Pet() {
			
		}
		
		@Override
		public String toString() {
			return "Pet [id=" + id + ", petName=" + petName + ", petAge=" + petAge + ", petPlace=" + petPlace
					+ ", petOwnerId=" + petOwnerId + "]";
		}
		public Pet(Long id, String petName, Integer petAge, String petPlace, Set<User> petOwnerId) {
			super();
			this.id = id;
			this.petName = petName;
			this.petAge = petAge;
			this.petPlace = petPlace;
			this.petOwnerId = petOwnerId;
		}
		public Long getId() {
			return id;
		}
}